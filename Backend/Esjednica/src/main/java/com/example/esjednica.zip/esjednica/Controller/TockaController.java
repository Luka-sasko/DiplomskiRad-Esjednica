package com.example.esjednica.Controller;

import com.example.esjednica.Model.Tocka;
import com.example.esjednica.Service.TockaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tocke")
public class TockaController {

    @Autowired
    private TockaService tockaService;

    @GetMapping("/sjednica/{sjednicaId}")
    public ResponseEntity<List<Tocka>> getTockeZaSjednicu(@PathVariable Long sjednicaId) {
        return ResponseEntity.ok(tockaService.findBySjednicaId(sjednicaId));
    }

    @PostMapping("/sjednica/{sjednicaId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'PREDLAGATELJ')")
    public ResponseEntity<Tocka> dodajTocku(@PathVariable Long sjednicaId, @RequestBody Tocka tocka) {
        tocka.setSjednicaId(sjednicaId);
        return ResponseEntity.ok(tockaService.saveTocka(tocka));
    }
}
